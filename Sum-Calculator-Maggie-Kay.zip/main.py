# ask user for number
num = int(input("Enter a positive integer: "))

# initialize counter
count = 0

# initialize sum
sum = 0

while (count <= num):
  sum = sum + count
  count = count + 1

print ("The sum of the numbers from 0 to", num, "is", sum)

